insert LopHoc(MaLop, TenLop)
values ('CNPM1','Cong nghe phan mem 1')